import 'package:flutter/material.dart';
import 'widgets/custom_slider.dart';
import 'widgets/custom_button.dart';
import 'widgets/settings_drawer.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  double iconSize = 100.0;
  Color iconColor = Colors.grey;
  bool allowResize = true;
  bool allowColorChange = true;

  void updateColor(Color color) {
    setState(() {
      iconColor = color;
    });
  }

  void updateSize(double size) {
    setState(() {
      iconSize = size;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('State Management App')),
      drawer: SettingsDrawer(
        allowResize: allowResize,
        allowColorChange: allowColorChange,
        onResizeToggle: (value) => setState(() => allowResize = value),
        onColorToggle: (value) => setState(() => allowColorChange = value),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.star, size: iconSize, color: iconColor),
          if (allowResize)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomButton(
                  icon: Icons.remove,
                  onPressed: () =>
                      updateSize((iconSize - 50).clamp(50.0, 500.0)),
                ),
                CustomButton(
                  icon: Icons.add,
                  onPressed: () =>
                      updateSize((iconSize + 50).clamp(50.0, 500.0)),
                ),
              ],
            ),
          if (allowColorChange)
            CustomSlider(
              currentColor: iconColor,
              onColorChange: updateColor,
            ),
        ],
      ),
    );
  }
}
