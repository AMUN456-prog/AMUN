import 'package:flutter/material.dart';

class SettingsDrawer extends StatelessWidget {
  final bool allowResize;
  final bool allowColorChange;
  final Function(bool) onResizeToggle;
  final Function(bool) onColorToggle;

  const SettingsDrawer({
    required this.allowResize,
    required this.allowColorChange,
    required this.onResizeToggle,
    required this.onColorToggle,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(color: Colors.blue),
            child: Text(
              'Settings',
              style: TextStyle(color: Colors.white, fontSize: 20),
            ),
          ),
          CheckboxListTile(
            title: Text('Allow Resize'),
            value: allowResize,
            onChanged: (value) {
              if (value != null) {
                onResizeToggle(value);
              }
            }, // Ensure null safety
          ),
          CheckboxListTile(
            title: Text('Allow Change Primer Color'),
            value: allowColorChange,
            onChanged: (value) {
              if (value != null) {
                onColorToggle(value);
              }
            }, // Ensure null safety
          ),
        ],
      ),
    );
  }
}
