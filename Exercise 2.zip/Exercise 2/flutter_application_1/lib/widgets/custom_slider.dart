import 'package:flutter/material.dart';

class CustomSlider extends StatelessWidget {
  final Color currentColor;
  final Function(Color) onColorChange;

  CustomSlider({required this.currentColor, required this.onColorChange});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        buildSliderRow('Red', currentColor.red, Colors.red, (value) {
          onColorChange(currentColor.withRed(value.toInt()));
        }),
        buildSliderRow('Green', currentColor.green, Colors.green, (value) {
          onColorChange(currentColor.withGreen(value.toInt()));
        }),
        buildSliderRow('Blue', currentColor.blue, Colors.blue, (value) {
          onColorChange(currentColor.withBlue(value.toInt()));
        }),
      ],
    );
  }

  Widget buildSliderRow(
      String label, int value, Color color, Function(double) onChanged) {
    return Row(
      children: [
        Expanded(
          child: Slider(
            value: value.toDouble(),
            min: 0,
            max: 255,
            activeColor: color,
            onChanged: onChanged,
          ),
        ),
        FloatingActionButton(
          backgroundColor: color,
          onPressed: () => onColorChange(color),
          child: Icon(Icons.color_lens),
        ),
      ],
    );
  }
}
